const grid = document.getElementById("grid");

// Convert HSL → HEX
function hslToHex(h, s, l) {
  s /= 100;
  l /= 100;

  let c = (1 - Math.abs(2 * l - 1)) * s;
  let x = c * (1 - Math.abs((h / 60) % 2 - 1));
  let m = l - c / 2;
  let r = 0, g = 0, b = 0;

  if (0 <= h && h < 60) [r, g, b] = [c, x, 0];
  else if (60 <= h && h < 120) [r, g, b] = [x, c, 0];
  else if (120 <= h && h < 180) [r, g, b] = [0, c, x];
  else if (180 <= h && h < 240) [r, g, b] = [0, x, c];
  else if (240 <= h && h < 300) [r, g, b] = [x, 0, c];
  else if (300 <= h && h < 360) [r, g, b] = [c, 0, x];

  r = Math.round((r + m) * 255).toString(16).padStart(2, "0");
  g = Math.round((g + m) * 255).toString(16).padStart(2, "0");
  b = Math.round((b + m) * 255).toString(16).padStart(2, "0");

  return `#${r}${g}${b}`;
}

// Generate colors (NO duplicates)
let colorSet = new Set();

for (let h = 0; h < 360; h += 2) {
  for (let s = 50; s <= 100; s += 10) {
    for (let l = 30; l <= 70; l += 10) {
      let hex = hslToHex(h, s, l);
      colorSet.add(hex);
    }
  }
}

// Convert to array
let colors = Array.from(colorSet);

// Shuffle (better visual randomness)
colors = colors.sort(() => Math.random() - 0.5);

// Render grid
function renderColors() {
  grid.innerHTML = "";

  colors.forEach(color => {
    const div = document.createElement("div");
    div.className = "color";
    div.style.background = color;

    // Interaction
    div.addEventListener("click", () => {
      document.body.style.background = color; // live preview
      console.log("Selected:", color);
    });

    grid.appendChild(div);
  });
}

// Run once
renderColors();